# 💱 Real-Time Currency Converter (Java)

A command-line based currency converter built using Java. This project demonstrates core Java concepts, collections, user input handling, and API-ready design.

## Features
- Convert currencies via CLI
- Add and view favorite currencies
- Modular Java code
- API-ready structure

## How to Run
javac CurrencyConverter.java
java CurrencyConverter

## Author
Shivaprasad Chinthoju
Email: shivaprasad7382@gmail.com
